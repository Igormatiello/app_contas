package com.example.myapplication.model

class Transaction (

    val id: Int = 0,
    val cre_deb: String,
    val descricao: String,
    val valor: Double,
    val data: String,
)